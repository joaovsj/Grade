<?php
    const DBDRIVE = "mysql";
    const DBHOST = "localhost";
    const DBNAME = "grades";
    const DBUSER = "root";
    const DBPASS = "";